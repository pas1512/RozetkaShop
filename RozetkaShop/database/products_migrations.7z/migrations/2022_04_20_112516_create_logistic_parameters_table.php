<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateLogisticParametersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('logistic_parameters', function (Blueprint $table) {
            $table->id();
            $table->float("packing_weight", 2);
            $table->float("packing_height", 2);
            $table->float("packing_width", 2);
            $table->float("packing_depth", 2);
            $table->unsignedInteger("packages_quantity");
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('logistic_parameters');
    }
}
